package pt.ulusofona.cm.kotlin.challenge

fun main() {
    // aqui escreves o código do programa

}