package pt.ulusofona.cm.kotlin.challenge

class Posicao{
    var x:Int
    var y:Int

   constructor(x:Int , y :Int){
       this.x=x;
       this.y=y;
   }

    override fun toString():String{
        return "pt.ulusofona.cm.kotlin.challenge.Posicao | x:0 | y:0"
    }
}