package pt.ulusofona.cm.kotlin.challenge

interface Ligavel {
    fun ligar()
    fun desligar()
    fun estaligafo():Boolean
}