package pt.ulusofona.cm.kotlin.challenge

class Carta {
}