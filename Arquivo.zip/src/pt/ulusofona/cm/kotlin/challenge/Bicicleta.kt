package pt.ulusofona.cm.kotlin.challenge

class Bicicleta {
    var identificador:String

   constructor(identificador:String){
       this.identificador=identificador

   }
}